const articleDetailContent = document.getElementById('articleDetailContent')

function readStorage(key) {
  return JSON.parse(localStorage.getItem(key) || '[]')
}

function getArticleId() {
  const params = new URLSearchParams(window.location.search)
  return params.get('id')
}

function renderArticleDetail() {
  if (!articleDetailContent) return

  const articleId = getArticleId()
  const articles = readStorage('rmsjArticles')
  const article = articles.find((item) => item.id === articleId)

  if (!article) {
    articleDetailContent.innerHTML = `
      <p class="eyebrow">Published article</p>
      <h1>Article not found</h1>
      <p class="section-copy">The requested article is not available yet. Please return to the articles list.</p>
    `
    return
  }

  document.title = `${article.title} | Rwanda Medical Student Journal`
  const fullText = article.content || article.abstract || 'No full text available yet.'
  const abstractText = article.abstract || 'No abstract available yet.'
  const referencesText = article.references || 'No references provided yet.'

  articleDetailContent.innerHTML = `
    <p class="eyebrow">${article.category || 'Published article'}</p>
    <h1>${article.title}</h1>
    <p class="article-detail-meta">
      <strong>Author:</strong> ${article.author}<br />
      <strong>Keywords:</strong> ${article.keywords || 'Open access'}<br />
      <strong>Published:</strong> ${article.createdAt || 'Recently submitted'}
    </p>

    <div class="article-section">
      <h2>Abstract</h2>
      <p class="article-detail-body">${abstractText.replace(/\n/g, '<br /><br />')}</p>
    </div>

    <div class="article-section">
      <h2>Main text</h2>
      <p class="article-detail-body">${fullText.replace(/\n/g, '<br /><br />')}</p>
    </div>

    <div class="article-section">
      <h2>References</h2>
      <p class="article-detail-body">${referencesText.replace(/\n/g, '<br /><br />')}</p>
    </div>
  `
}

renderArticleDetail()
