const publicArticlesList = document.getElementById('publicArticlesList')

function readStorage(key) {
  return JSON.parse(localStorage.getItem(key) || '[]')
}

function renderPublicArticles() {
  if (!publicArticlesList) return

  const articles = readStorage('rmsjArticles')
  if (!articles.length) {
    publicArticlesList.innerHTML = '<article class="article-card"><p class="portal-empty">No published articles yet. Authors can submit new work from the portal.</p></article>'
    return
  }

  publicArticlesList.innerHTML = articles.map((article) => `
    <article class="article-card">
      <p class="article-tag">${article.category || 'General'}</p>
      <h2>${article.title}</h2>
      <p class="article-meta">${article.author} · ${article.keywords || 'Open access'} · ${article.createdAt || 'Published'}</p>
      <p>${article.abstract}</p>
      <div class="article-actions">
        <span>Status: ${article.status || 'Published'}</span>
        <a href="article-detail.html?id=${article.id}" class="link-button">Read more</a>
      </div>
    </article>
  `).join('')
}

renderPublicArticles()
