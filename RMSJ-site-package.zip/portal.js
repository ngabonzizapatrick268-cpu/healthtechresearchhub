const registerForm = document.getElementById('registerForm')
const loginForm = document.getElementById('loginForm')
const authMessage = document.getElementById('authMessage')
const articleForm = document.getElementById('articleForm')
const articleList = document.getElementById('articleList')
const reviewList = document.getElementById('reviewList')
const authView = document.getElementById('authView')
const dashboardView = document.getElementById('dashboardView')
const welcomeTitle = document.getElementById('welcomeTitle')
const userRoleText = document.getElementById('userRoleText')
const logoutBtn = document.getElementById('logoutBtn')
const articleMessage = document.getElementById('articleMessage')

function readStorage(key) {
  return JSON.parse(localStorage.getItem(key) || '[]')
}

function writeStorage(key, value) {
  localStorage.setItem(key, JSON.stringify(value))
}

function getCurrentUser() {
  return JSON.parse(localStorage.getItem('rmsjCurrentUser') || 'null')
}

function saveCurrentUser(user) {
  localStorage.setItem('rmsjCurrentUser', JSON.stringify(user))
}

function clearCurrentUser() {
  localStorage.removeItem('rmsjCurrentUser')
}

function showDashboard(user) {
  if (authView) authView.classList.add('hidden')
  if (dashboardView) dashboardView.classList.remove('hidden')
  if (welcomeTitle) welcomeTitle.textContent = `Welcome, ${user.username}`
  if (userRoleText) userRoleText.textContent = `Role: ${user.role}. You can create, preview, and submit articles from this portal.`
  renderArticles()
  renderReviews()
}

function showAuth() {
  if (authView) authView.classList.remove('hidden')
  if (dashboardView) dashboardView.classList.add('hidden')
}

function renderArticles() {
  const user = getCurrentUser()
  const articles = readStorage('rmsjArticles').filter((item) => item.author === user?.username)
  if (!articleList) return
  if (articles.length === 0) {
    articleList.innerHTML = '<p class="portal-empty">No articles yet.</p>'
    return
  }
  articleList.innerHTML = articles.map((article) => `
    <article class="portal-item">
      <h3>${article.title}</h3>
      <p>${article.abstract}</p>
      <div class="portal-meta">
        <span>${article.category || 'General'}</span>
        <span>${article.keywords || 'No keywords'}</span>
      </div>
    </article>
  `).join('')
}

function renderReviews() {
  const user = getCurrentUser()
  const articles = readStorage('rmsjArticles')
  if (!reviewList) return
  const relevant = articles.filter((item) => user?.role === 'admin' || user?.role === 'reviewer' || item.author === user?.username)
  if (relevant.length === 0) {
    reviewList.innerHTML = '<p class="portal-empty">No review items yet.</p>'
    return
  }
  reviewList.innerHTML = relevant.map((article) => `
    <article class="portal-item">
      <h3>${article.title}</h3>
      <p>${article.abstract}</p>
      <p class="portal-meta">Author: ${article.author} · Status: ${article.status || 'Published'}</p>
    </article>
  `).join('')
}

if (registerForm) {
  registerForm.addEventListener('submit', function (event) {
    event.preventDefault()
    const formData = new FormData(registerForm)
    const users = readStorage('rmsjUsers')
    const username = String(formData.get('username') || '').trim()
    const password = String(formData.get('password') || '').trim()
    const email = String(formData.get('email') || '').trim()
    const role = String(formData.get('role') || 'author')

    if (!username || !password || !email) {
      if (authMessage) authMessage.textContent = 'Please complete all fields.'
      return
    }

    if (users.some((user) => user.username === username)) {
      if (authMessage) authMessage.textContent = 'That username already exists.'
      return
    }

    const newUser = { username, email, password, role }
    users.push(newUser)
    writeStorage('rmsjUsers', users)
    saveCurrentUser(newUser)
    if (authMessage) authMessage.textContent = 'Account created. You are now signed in.'
    showDashboard(newUser)
  })
}

if (loginForm) {
  loginForm.addEventListener('submit', function (event) {
    event.preventDefault()
    const formData = new FormData(loginForm)
    const username = String(formData.get('username') || '').trim()
    const password = String(formData.get('password') || '').trim()
    const users = readStorage('rmsjUsers')
    const matchedUser = users.find((user) => user.username === username && user.password === password)

    if (!matchedUser) {
      if (authMessage) authMessage.textContent = 'Invalid username or password.'
      return
    }

    saveCurrentUser(matchedUser)
    if (authMessage) authMessage.textContent = 'Signed in successfully.'
    showDashboard(matchedUser)
  })
}

if (articleForm) {
  articleForm.addEventListener('submit', function (event) {
    event.preventDefault()
    const user = getCurrentUser()
    if (!user) return

    const formData = new FormData(articleForm)
    const article = {
      id: `article-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      title: String(formData.get('title') || '').trim(),
      category: String(formData.get('category') || '').trim(),
      keywords: String(formData.get('keywords') || '').trim(),
      abstract: String(formData.get('abstract') || '').trim(),
      content: String(formData.get('content') || '').trim(),
      references: String(formData.get('references') || '').trim(),
      author: user.username,
      status: 'Published',
      createdAt: new Date().toLocaleString(),
    }

    const articles = readStorage('rmsjArticles')
    articles.push(article)
    writeStorage('rmsjArticles', articles)
    articleForm.reset()
    if (articleMessage) articleMessage.textContent = 'Article saved successfully and sent to review.'
    renderArticles()
    renderReviews()
  })
}

if (logoutBtn) {
  logoutBtn.addEventListener('click', function () {
    clearCurrentUser()
    showAuth()
  })
}

const currentUser = getCurrentUser()
if (currentUser) {
  showDashboard(currentUser)
} else {
  showAuth()
}
