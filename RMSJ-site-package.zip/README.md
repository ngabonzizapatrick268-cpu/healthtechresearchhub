# Rwanda Medical Student Journal (RMSJ)

This repository contains the RMSJ journal platform.

## Project structure

- `rmsj-backend/` - Django REST API backend
- `rmsj-frontend/` - Next.js TypeScript frontend

## Local development

1. Backend
   - Activate your Python virtual environment.
   - Run migrations:
     ```powershell
     cd rmsj-backend
     & ".\.venv\Scripts\python.exe" manage.py migrate
     & ".\.venv\Scripts\python.exe" manage.py runserver
     ```
   - Open `http://localhost:8000`

2. Frontend
   - Install Node.js and npm if not already installed.
   - Run from the frontend folder:
     ```powershell
     cd rmsj-frontend
     npm install
     npm run dev
     ```
   - Open `http://localhost:3000`

## GitHub publishing

1. Create a new GitHub repository, for example `rmsj`.
2. In this project folder, run:
   ```powershell
   git init
   git add .
   git commit -m "Initial RMSJ project"
   git remote add origin https://github.com/<your-username>/rmsj.git
   git push -u origin main
   ```
3. For a live website, deploy the frontend via Vercel or Netlify and the backend via Railway, Render, or a Docker-friendly hosting provider.

## Notes

- This repository is ready for GitHub source control.
- The frontend is designed for a modern responsive RMSJ homepage and auth flow.
- The backend supports local Django development and can be configured for PostgreSQL or SQLite.
