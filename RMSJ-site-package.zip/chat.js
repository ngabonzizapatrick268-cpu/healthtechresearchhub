const aiChatToggle = document.getElementById('aiChatToggle')
const aiChatButton = document.getElementById('aiChatButton')
const aiChatWidget = document.getElementById('aiChatWidget')
const aiChatClose = document.getElementById('aiChatClose')
const aiChatForm = document.getElementById('aiChatForm')
const aiChatInput = document.getElementById('aiChatInput')
const aiChatMessages = document.getElementById('aiChatMessages')

const AI_RESPONSES = {
  submissions: 'For authors: register as an author, complete the submission form, and submit your manuscript for review. The editorial team will contact you soon.',
  review: 'Reviewers receive assignments through the reviewer dashboard. Each task includes the article abstract and submission details.',
  contact: 'You can contact Rwanda Medical Student Journal by phone at +25079244721 for submissions and editorial inquiries.',
  ai: 'RMSJ AI can help you with article categories, submission guidance, and journal policies. Ask about research topics, review process, or publication support.',
  default: 'RMSJ AI can answer questions about author submission, review workflow, and contact support. Try asking about submissions, article types, or the +25079244721 contact number.',
}

function openChat() {
  if (aiChatWidget) {
    aiChatWidget.classList.remove('hidden')
  }
}

function closeChat() {
  if (aiChatWidget) {
    aiChatWidget.classList.add('hidden')
  }
}

function addMessage(message, className) {
  if (!aiChatMessages) return
  const messageEl = document.createElement('div')
  messageEl.className = `chat-message ${className}`
  messageEl.textContent = message
  aiChatMessages.appendChild(messageEl)
  aiChatMessages.scrollTop = aiChatMessages.scrollHeight
}

function getAnswer(question) {
  const cleaned = question.toLowerCase()
  if (cleaned.includes('submit') || cleaned.includes('submission')) return AI_RESPONSES.submissions
  if (cleaned.includes('review')) return AI_RESPONSES.review
  if (cleaned.includes('contact') || cleaned.includes('phone')) return AI_RESPONSES.contact
  if (cleaned.includes('ai') || cleaned.includes('chat')) return AI_RESPONSES.ai
  return AI_RESPONSES.default
}

if (aiChatToggle) {
  aiChatToggle.addEventListener('click', openChat)
}

if (aiChatButton) {
  aiChatButton.addEventListener('click', openChat)
}

if (aiChatClose) {
  aiChatClose.addEventListener('click', closeChat)
}

if (aiChatForm) {
  aiChatForm.addEventListener('submit', function (event) {
    event.preventDefault()
    if (!aiChatInput) return
    const question = aiChatInput.value.trim()
    if (!question) return
    addMessage(question, 'user')
    const answer = getAnswer(question)
    setTimeout(() => addMessage(answer, 'bot'), 400)
    aiChatInput.value = ''
  })
}

const contactForm = document.getElementById('contactForm')
const contactFormMessage = document.getElementById('contactFormMessage')

if (contactForm) {
  contactForm.addEventListener('submit', function (event) {
    event.preventDefault()
    const formData = new FormData(contactForm)
    const name = formData.get('name') || ''
    const email = formData.get('email') || ''
    const subject = formData.get('subject') || 'Contact from RMSJ'
    const message = formData.get('message') || ''
    const mailtoLink = `mailto:ngabonzizapatrick@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`)}`
    window.location.href = mailtoLink
    if (contactFormMessage) {
      contactFormMessage.textContent = 'Your message is ready to send. If the mail app does not open, email ngabonzizapatrick@gmail.com directly.'
    }
  })
}
